package com.jdc.test

import javafx.application.Application
import javafx.fxml.FXMLLoader
import javafx.scene.Scene
import javafx.stage.Stage

class Home: Application()  {
    override fun start(primaryStage: Stage) {

        primaryStage.scene = Scene(FXMLLoader.load(javaClass.getResource("Home.fxml")))
        primaryStage.show()// o change body of created functions use File | Settings | File Templates.
    }
}