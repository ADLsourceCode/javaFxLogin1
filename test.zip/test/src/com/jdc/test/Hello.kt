package com.jdc.test

import javafx.application.Application
import javafx.stage.Stage
import javafx.scene.control.Label
import  javafx.scene.control.TextField
import javafx.fxml.FXML
import javafx.fxml.FXMLLoader
import javafx.scene.Node
import javafx.scene.Scene
import javafx.scene.control.Alert
import java.net.http.HttpClient
import java.net.http.HttpRequest
//import com.fasterxml.jackson.databind.ObjectMapper
import java.net.URI
import java.net.http.HttpResponse
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue
import java.awt.event.MouseEvent
import java.util.prefs.Preferences
import java.io.IOException
import javafx.scene.Parent
import javafx.scene.control.Button
import java.awt.event.ActionEvent


class Hello: Application() {


    @FXML lateinit var username:TextField
    @FXML lateinit var password:TextField
    @FXML lateinit var usernameError:Label
    @FXML lateinit var passwordError:Label
//    @FXML lateinit var light:Button


    lateinit var  stage: Stage

    var isLight:Boolean=true



    fun login(){



        if(username.text.length==0)
        {
            usernameError.text="Username is Required"
        }
        else if(password.text.length==0)
        {
            passwordError.text="Password is Required"
        }
        else{
            val values = "{ \n" +
                    "\"username\": \"${username.text}\", \n" +
                    "\"password\": \""+password.text+"\"}"



            val client = HttpClient.newBuilder().build();
            val request = HttpRequest.newBuilder()
                .uri(URI.create("http://private-222d3-homework5.apiary-mock.com/api/login"))
                .POST(HttpRequest.BodyPublishers.ofString(values))
                .build()
            val response = client.send(request, HttpResponse.BodyHandlers.ofString());

            val obj = JSONValue.parse(response.body())
            val jsonObject = obj as JSONObject

                if(jsonObject.get("errorCode")=="00")
                {

                    val userPreferences = Preferences.userRoot()
                    userPreferences.put("username", username.text)
                    userPreferences.put("password", password.text)

                    val primaryStage:Stage = Stage()
                    primaryStage.scene = Scene(FXMLLoader.load(javaClass.getResource("Home.fxml")))
                    primaryStage.show()


                }
                else
                {
                    Alert(Alert.AlertType.NONE,jsonObject.get("errorMessage").toString()).show();
                }
        }
    }

    lateinit var scene: Scene



    override fun start(primaryStage: Stage) {

         scene = Scene(FXMLLoader.load(javaClass.getResource("Hello.fxml")))

            scene.stylesheets.add("com/jdc/test/light.css")



        primaryStage.scene = scene

        primaryStage.isResizable  =false
        primaryStage.title="Login"
        primaryStage.show()






    }
}


fun main(arg: Array<String>) {
    Application.launch(Hello::class.java)

}